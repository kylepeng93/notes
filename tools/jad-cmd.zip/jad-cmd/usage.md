在cmd中执行如下代码（注意，jdk版本应该在1.6以上）
java -jar jad-cmd.jar [你要反编译的jar包] -od [你要保存反编译之后的文件的木
录]
